package com.SmartBinAnalytics.Controller;
public interface WEB
{
	public String APP_CONTEXT="SmartBinAnalytics";
	public String DASHBOARD="jsp/dashboard.jsp";
	public String BINS="jsp/bins.jsp";
	public String LOGOUT="jsp/logoutUser.jsp";
	public String LOGIN="Login.java";
}