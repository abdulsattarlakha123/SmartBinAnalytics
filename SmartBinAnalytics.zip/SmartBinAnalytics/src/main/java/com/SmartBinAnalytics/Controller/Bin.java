package com.SmartBinAnalytics.Controller;



import org.apache.jena.iri.impl.Main;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.util.FileManager;

public class Bin {
	public String getBinHistory() {
		FileManager.get().addLocatorClassLoader(Main.class.getClassLoader());
		Model model1=FileManager.get().loadModel("C:\\Users\\abdul\\Documents\\workspace-spring-tool-suite-4-4.7.0.RELEASE\\SmartBinAnalytics\\src\\main\\webapp\\OWL\\OntoWM2.0.owl");

	    
		String queryString1=
				"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n" + 
						"PREFIX v2: <https://www.ontowm.com/v2.0#>\r\n" + 
						"PREFIX owl: <http://www.w3.org/2002/07/owl#>\r\n" + 
						"PREFIX v22: <https://www.ontowm.com/v2.owl#>\r\n" + 
						"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" + 
						"PREFIX xml: <http://www.w3.org/XML/1998/namespace>\r\n" + 
						"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n" + 
						//"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n" + 
				"SELECT  * WHERE { "+
				"?subject v2:binCode ?binCode ."+
				 "?subject v22:collectionDate ?CollectionDate ."+
				"}"
				+ "ORDER BY ?binCode ";
		
		String output="";
		
		Query query1=QueryFactory.create(queryString1);
		QueryExecution queryExec1=QueryExecutionFactory.create(query1,model1);
		
		try 
			{
				ResultSet rs1= queryExec1.execSelect();
				//ResultSet rs2= queryExec2.execSelect();
				//int i=1;
				while (rs1.hasNext() )
				{
					QuerySolution soln1=rs1.nextSolution();
					Literal CollectionDate=soln1.getLiteral("CollectionDate");
					Literal binCode=soln1.getLiteral("binCode");
					
					output+=  binCode + "," + CollectionDate+"<br>";  //e.g 1,2020-06-12 08:00:20
					
				} // end of while
				
				
			} // end of try
			finally
			{
				queryExec1.close();
			}
		return output;
	}  // end of getBinHistory
	public String getBinsFromOWL() {
		FileManager.get().addLocatorClassLoader(Main.class.getClassLoader());
		Model model1=FileManager.get().loadModel("C:\\Users\\abdul\\Documents\\workspace-spring-tool-suite-4-4.7.0.RELEASE\\SmartBinAnalytics\\src\\main\\webapp\\OWL\\OntoWM2.0.owl");

	    
		String queryString1=
				"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n" + 
						"PREFIX v2: <https://www.ontowm.com/v2.0#>\r\n" + 
						"PREFIX owl: <http://www.w3.org/2002/07/owl#>\r\n" + 
						"PREFIX v22: <https://www.ontowm.com/v2.owl#>\r\n" + 
						"PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" + 
						"PREFIX xml: <http://www.w3.org/XML/1998/namespace>\r\n" + 
						"PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n" + 
						//"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n" + 
				"SELECT  * WHERE { "+
				"?subject v2:binCode ?binCode ."+
				"?subject v2:latitude ?latitude ."+
				"?subject v2:longitude ?longitude ."+
				"?subject v22:binStatus ?binStatus ."+
				"}";
		
		String output="";
		
		Query query1=QueryFactory.create(queryString1);
		QueryExecution queryExec1=QueryExecutionFactory.create(query1,model1);
		
		try 
			{
				ResultSet rs1= queryExec1.execSelect();
				//ResultSet rs2= queryExec2.execSelect();
				int i=1;
				while (rs1.hasNext() )
				{
					QuerySolution soln1=rs1.nextSolution();
					Literal binCode=soln1.getLiteral("binCode");
					Literal binStatus=soln1.getLiteral("binStatus");
					Literal longitude=soln1.getLiteral("longitude");
					Literal latitude=soln1.getLiteral("latitude");
					
					output+=  binCode + "--" + binStatus+ "--" + longitude+ "--" + latitude+":";  //e.g 1,availabe;2,available;
					//System.out.println(name);
					
				} // end of while
				
				
			} // end of try
			finally
			{
				queryExec1.close();
				//queryExec2.close();
			}
		
			//output+= "<br>sattar ";
		return output;
	}  // end of getBinsFromOWL
} // end of class
