package com.SmartBinAnalytics.Model;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDb {
	String s1=null;
	public String insertUser(String name, String email, String password) {
		MyDb db=new MyDb();
		Connection con= db.getCon();
		try {
			Statement stmt= con.createStatement();
			String query=" INSERT INTO myusers(user_name,user_email,user_password) VALUES ('"+ name +"','"+ email +"','"+ password + "')  ";
			stmt.executeUpdate(query);
			s1="Data Inserted Successfully! ";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s1;
	}
	public String verifyUser(String name, String password) {
		MyDb db=new MyDb();
		Connection con= db.getCon();
		try {
			Statement stmt= con.createStatement();
			String query=" SELECT * FROM myusers WHERE user_name='"+ name +"' AND user_password= '"+ password + "'  ";
			//System.out.println(query);
			ResultSet rs= stmt.executeQuery(query);
			if(rs.next())
				return "valid";
			else
				return "invalid";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s1;
	}
}
